#ifndef __USE_GNU
#define __USE_GNU
#endif

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>
#include <sched.h>
#include <sys/time.h>
#include <time.h>





#define errExit(msg)    do { perror(msg); exit(EXIT_FAILURE); \
                               } while (0)


int main(int argc, char *argv[]) {

		struct timeval start_c;
	    struct timeval finish_c;
	    struct timeval start_P;
	    struct timeval finish_P;

	    double start_usec_C;
	    double finish_usec_C;
	    double start_usec_P;
	    double finish_usec_P;

	    gettimeofday(&start_P, NULL);


	 cpu_set_t set;

	 int CPU_parent, CPU_child;

	 CPU_parent = 0;
	 CPU_child = 0;

		int     pipeone[2], pipetwo[2];
		pid_t   child;
		char    string1[] = "Child to Parent!\n";
		char    string2[] = "Parent to Child!\n";
		char    readbuffer_C[80];
		char    readbuffer_P[80];



		pipe(pipeone);
		pipe(pipetwo);

	     CPU_ZERO(&set);//clear all CPUs

		if((child = fork()) == -1)
		{
				perror("fork");
				exit(1);
		}

		if(child == 0)
		{
			CPU_SET(CPU_child, &set);

			if (sched_setaffinity(getpid(), sizeof(set), &set) == -1)
			                   errExit("sched_setaffinity");

				/* Child process closes up input side of pipe1 and output side of pipe2*/
				close(pipeone[0]);
				close(pipetwo[1]);

				gettimeofday(&start_c, NULL);

				/* Send "string" through the output side of pipe */
				write(pipeone[1], string1, strlen(string1)+1);


				read(pipetwo[0], readbuffer_C, sizeof(readbuffer_C));

				gettimeofday(&finish_c, NULL);

				printf("Received string: %s", readbuffer_C);

				int cpu = 0;

				cpu = sched_getcpu();

				printf("Child CPU number is %d\n",cpu);

				start_usec_C = (start_c.tv_sec) + start_c.tv_usec/1000000.0 ;
				finish_usec_C = (finish_c.tv_sec ) + finish_c.tv_usec/1000000.0 ;

				double result_C = (finish_usec_C - start_usec_C);

				printf("context for child: %lf\n",result_C);


				exit(0);
		}
		else
		{
			CPU_SET(CPU_parent, &set);

			   if (sched_setaffinity(getpid(), sizeof(set), &set) == -1)
				   errExit("sched_setaffinity");

				/* Parent process closes up output side of pipe1 and input side of pipe2 */
				close(pipeone[1]);
				close(pipetwo[0]);

				/* Read in a string from the pipe */
				read(pipeone[0], readbuffer_P, sizeof(readbuffer_P));

				gettimeofday(&finish_P, NULL);

				start_usec_P = (start_P.tv_sec) + start_P.tv_usec/1000000.0 ;
								finish_usec_P = (finish_P.tv_sec ) + finish_P.tv_usec/1000000.0 ;

								double result_P = (finish_usec_P - start_usec_P);

								printf("context for Parent: %lf\n",result_P);

				printf("Received string: %s", readbuffer_P);

				write(pipetwo[1], string2, strlen(string2)+1);


									int cpu = 0;

													cpu = sched_getcpu();

													printf("Parent CPU number is %d\n",cpu);

				waitpid(child,NULL,0);
		}

		return(0);
}





