#ifndef __USE_GNU
#define __USE_GNU
#endif

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <string.h>
#include <sched.h>
#include <sys/time.h>
#include <time.h>





#define errExit(msg)    do { perror(msg); exit(EXIT_FAILURE); \
                               } while (0)



int main(int argc, char *argv[]){
    
	struct timeval start;
     struct timeval finish;

     double time_start;
     double time_finish;

 cpu_set_t set;

	 int p_cpu =0, c_cpu =0;

	

CPU_ZERO(&set);//clear all CPUs
//getting time value before process creation

    gettimeofday(&start, NULL);

    int c = 0;
    for (c = 0; c < 100; c++)
    {
		int child = fork();

		if (child < 0) {// fork failure
			fprintf(stderr, "fork failed\n");
			exit(1);
			} else if (child == 0) { 
                              // child process enters here
CPU_SET(c_cpu, &set);

			if (sched_setaffinity(getpid(), sizeof(set), &set) == -1)
			                   errExit("sched_setaffinity");

				
				exit(0);

			}
 else { 
CPU_SET(p_cpu, &set);
//parent process enters below
if (sched_setaffinity(getpid(), sizeof(set), &set) == -1)
				   errExit("sched_setaffinity");

			waitpid(child,NULL,0);
			
		}
    }

//getting time value after process creation
    gettimeofday(&finish, NULL); 

//conversion of time from nanosecond to sec

    time_start = (start.tv_sec) + start.tv_usec/1000000.0 ;
    time_finish = (finish.tv_sec ) + finish.tv_usec/1000000.0 ;


         /* time required for creating forks */ 
    double result = (time_finish - time_start);

    printf("%lf\n",result/100); // time required for each fork

    return 0;
}




