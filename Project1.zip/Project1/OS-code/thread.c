
#define _GNU_SOURCE
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <time.h>
#include <sys/time.h>

       #define handle_error_en(en, msg) \
               do { errno = en; perror(msg); exit(EXIT_FAILURE); } while (0)


void *threadFunc(void *vargp)
{

    printf("Printing from Thread \n");
    return NULL;
}
  
int main()
{

pthread_t tid1;
	pthread_t tid2;
	pthread_t tid3;
	pthread_t tid4;
pthread_t tid5;
	pthread_t tid6;
	pthread_t tid7;
	pthread_t tid8;
	
	struct timeval start;
    struct timeval finish;

    double start_usec;
    double finish_usec;

int s, j = 0; //setting cpu core from where the code will run
	           cpu_set_t cpuset;
	           pthread_t thread;

	           thread = pthread_self();

	           /* Set affinity mask to include CPUs 0 to 7 */

	           CPU_ZERO(&cpuset);
 CPU_SET(j, &cpuset);

	           s = pthread_setaffinity_np(thread, sizeof(cpu_set_t), &cpuset);

	
	gettimeofday(&start, NULL);




 printf("Before Thread\n");
	
		pthread_create(&tid1, NULL, threadFunc, NULL);
		pthread_create(&tid2, NULL, threadFunc, NULL);
		pthread_create(&tid3, NULL, threadFunc, NULL);
		pthread_create(&tid4, NULL, threadFunc, NULL);
		pthread_create(&tid5, NULL, threadFunc, NULL);
		pthread_create(&tid6, NULL, threadFunc, NULL);
		pthread_create(&tid7, NULL, threadFunc, NULL);
		pthread_create(&tid8, NULL, threadFunc, NULL);

			                     s = pthread_setaffinity_np(tid1, sizeof(cpuset), &cpuset);
			                     if (s == -1)
			                         handle_error_en(s, " problem 1 pthread_setaffinity_np");

			                     s = pthread_setaffinity_np(tid2, sizeof(cpuset), &cpuset);
			                     if (s == -1)
			                    	 	handle_error_en(s, " problem 2 pthread_setaffinity_np");

			                 s = pthread_setaffinity_np(tid3, sizeof(cpuset), &cpuset);
			                     			                  if (s == -1)
			                     			                    	 	handle_error_en(s, " problem 3 pthread_setaffinity_np");

							pthread_setaffinity_np(tid4, sizeof(cpuset), &cpuset);
			                     			                  if (s == -1)
			                     			                    	 	handle_error_en(s, " problem 3 pthread_setaffinity_np");



			                     s = pthread_setaffinity_np(tid5, sizeof(cpuset), &cpuset);
			                     if (s == -1)
			                         handle_error_en(s, " problem 1 pthread_setaffinity_np");

			                     s = pthread_setaffinity_np(tid6, sizeof(cpuset), &cpuset);
			                     if (s == -1)
			                    	 	handle_error_en(s, " problem 2 pthread_setaffinity_np");

			                 s = pthread_setaffinity_np(tid7, sizeof(cpuset), &cpuset);
			                     			                  if (s == -1)
			                     			                    	 	handle_error_en(s, " problem 3 pthread_setaffinity_np");

							pthread_setaffinity_np(tid8, sizeof(cpuset), &cpuset);
			                     			                  if (s == -1)
			                     			                    	 	handle_error_en(s, " problem 3 pthread_setaffinity_np");


		pthread_join(tid1, NULL);
		pthread_join(tid2, NULL);
		pthread_join(tid3, NULL);
		pthread_join(tid4, NULL);
			pthread_join(tid5, NULL);
		pthread_join(tid6, NULL);
		pthread_join(tid7, NULL);
		pthread_join(tid8, NULL);
	
    printf("After Thread\n");
    gettimeofday(&finish, NULL);

    start_usec = (start.tv_sec) + start.tv_usec/1000000.0 ;
    finish_usec = (finish.tv_sec ) + finish.tv_usec/1000000.0 ;

    double result = (finish_usec - start_usec)/8.0;

    printf("%lf\n",result);

    return 0;
}
